import {axios} from '@/utils/request'
import Qs from 'qs'
const api = {
  allNote: '/note/allNote',
  noteDetail: '/note/noteDetail',
};

export default api

export function getNoteList() {
  return axios({
    url: api.allNote,
    method: 'post',

  })
}

export function getNoteDetail(data) {
  return axios({
    url: api.noteDetail,
    method: 'post',
    data: data,
    // data: Qs.stringify(data),
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

