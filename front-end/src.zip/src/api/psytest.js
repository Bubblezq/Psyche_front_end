import {axios} from '@/utils/request'
import Qs from 'qs'

const api = {
  allTest: '/psytest/allTest',
  testDetail: '/psytest/testDetail',
};

export default api

export function getTestList(data) {
  return axios({
    url: api.allTest,
    method: 'post',
    data:data,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }

  })
}

export function getTestDetail(data) {
  return axios({
    url: api.testDetail,
    method: 'post',
    data: data,
    // data: Qs.stringify(data),
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  })
}

