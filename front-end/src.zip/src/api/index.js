const api = {
  Login: '/auth/login',
  Logout: '/auth/logout',
  // get my info
  UserInfo: '/user/info'
}
export default api
