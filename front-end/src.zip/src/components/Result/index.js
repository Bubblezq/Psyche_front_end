import Result from './Result.vue'
export default Result
