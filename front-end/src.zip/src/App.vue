<template>
  <a-locale-provider :locale="locale">
    <div id="app">
      <router-view v-if="isRouterAlive"></router-view>
    </div>
  </a-locale-provider>
</template>

<script>
import zhCN from 'ant-design-vue/lib/locale-provider/zh_CN'
import { AppDeviceEnquire } from '@/utils/mixin'

export default {
  mixins: [AppDeviceEnquire],
  provide(){
      return{
          reload: this.reload
      }
  },
  data () {
    return {
      locale: zhCN,
      isRouterAlive: true
    }
  },
    created () {
        //在页面加载时读取sessionStorage里的状态信息
        if (sessionStorage.getItem("store") ) {
            this.$store.replaceState(Object.assign({}, this.$store.state,JSON.parse(sessionStorage.getItem("store"))));
            sessionStorage.removeItem('store');
        }

        //在页面刷新时将vuex里的信息保存到sessionStorage里
        window.addEventListener("beforeunload",()=>{
            sessionStorage.setItem("store",JSON.stringify(this.$store.state))
        })
    },
  methods:{
    reload (){
     this.isRouterAlive = false
     this.$nextTick(() => (this.isRouterAlive = true))
    },
  },
  mounted () {

  }
}
</script>
<style>
  #app {
    height: 100%;
  }
</style>
