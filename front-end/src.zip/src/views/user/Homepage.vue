<template>

  <div>
    <a-row :gutter="24">
      <a-col :xl="24" :lg="24" :md="24" :sm="24" :xs="24">

        <!--首页横幅-->
        <a-carousel arrows autoplay>
          <div
            slot="prevArrow"
            slot-scope="props"
            class="custom-slick-arrow"
            style="left: 10px;zIndex: 1"
          >
            <a-icon type="left-circle"/>
          </div>
          <div slot="nextArrow" slot-scope="props" class="custom-slick-arrow" style="right: 10px">
            <a-icon type="right-circle"/>
          </div>
          <router-link :to="{name:'myPage'}" >
            <img src="../../assets/bg1.png" alt="P1" align="middle">
          </router-link>
          <div><h3>2</h3></div>
          <div><h3>3</h3></div>
          <div><h3>4</h3></div>
          <div><h3>4</h3></div>
        </a-carousel>


        <!--调度管理-->
        <a-card
          class="project-list"
          :loading="loading"
          style="margin-bottom: 24px; margin-top: 0px"
          :bordered="false"
          title="调度管理"
          :body-style="{ padding: 0 }">
          <a-card>
            <a-row :gutter="24">
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="仓库预览"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562590986/warehouse.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'Preview'}" active-class="active">
                    <a-card-meta
                      title="仓库预览"
                      description="点击预览仓库信息">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="仓库地图"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562593159/map.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'Map'}" active-class="active">
                    <a-card-meta
                      title="仓库地图"
                      description="点击查看仓库地图">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="仓储器材"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562593108/equipment.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'EquipPreview'}" active-class="active">
                    <a-card-meta
                      title="仓储器材"
                      description="点击预览仓储器材">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="在用器材"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562593722/equipmentUsing.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'EquipUsing'}" active-class="active">
                    <a-card-meta
                      title="在用器材"
                      description="点击查询在用器材">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
            </a-row>
            <br/>
            <a-row :gutter="24">
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="更多"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562599516/more.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'AccessoryInWarehouse'}" active-class="active">
                    <a-card-meta
                      title="配件管理"
                      description="点击管理器材配件">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="工单预览"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562593143/gongdan.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'workSheet'}" active-class="active">
                    <a-card-meta
                      title="工单预览"
                      description="点击预览工单信息">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="报修单预览"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562593110/baoxiudan.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'repairSheet'}" active-class="active">
                    <a-card-meta
                      title="报修单预览"
                      description="点击预览报修单信息">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
              <a-col :md="24" :lg="6">
                <a-card hoverable>
                  <img
                    alt="巡检单预览"
                    src="https://res.cloudinary.com/dbmkzs2ez/image/upload/v1562593181/xunjiandan.png"
                    slot="cover"
                  />
                  <router-link :to="{name: 'checkSheet'}" active-class="active">
                    <a-card-meta
                      title="巡检单预览"
                      description="点击预览巡检单信息">
                    </a-card-meta>
                  </router-link>
                </a-card>
              </a-col>
            </a-row>
          </a-card>
        </a-card>

        <!--动态-->
        <a-card :loading="loading" title="动态" :bordered="false">
          <a-list>
            <a-list-item :key="index" v-for="(item, index) in activities">
              <a-list-item-meta>
                <a-avatar slot="avatar" :src="item.user.avatar"/>
                <div slot="title">
                  <span>{{ item.user.nickname }}</span>&nbsp;
                  在&nbsp;<a href="#">{{ item.project.name }}</a>&nbsp;
                  <span>{{ item.project.action }}</span>&nbsp;
                  <a href="#">{{ item.project.event }}</a>
                </div>
                <div slot="description">{{ item.time }}</div>
              </a-list-item-meta>
            </a-list-item>
          </a-list>
        </a-card>
      </a-col>

      <!--个人信息-->
      <a-col
        style="padding: 0 12px"
        :xl="8"
        :lg="24"
        :md="24"
        :sm="24"
        :xs="24">
        <a-card
          class="project-list"
          :loading="loading"
          style="margin-bottom: 24px; margin-top: 0px"
          :bordered="false"
          title="个人信息"
          :body-style="{ padding: 0 }">
          <a-card>
            <a-icon type="unlock"/>
          </a-card>
        </a-card>
      </a-col>
    </a-row>
  </div>

</template>

<script>
  import {timeFix} from '@/utils/util'
  import {mapGetters} from 'vuex'

  import {PageView} from '@/layouts'
  import HeadInfo from '@/components/tools/HeadInfo'
  import {Radar} from '@/components'

  import {getRoleList, getServiceList} from '@/api/manage'

  const DataSet = require('@antv/data-set')

  export default {
    name: 'Homepage',
    components: {
      PageView,
      HeadInfo,
      Radar
    },
    data() {
      return {
        timeFix: timeFix(),
        avatar: '',
        user: {},

        projects: [],
        loading: true,
        radarLoading: true,
        activities: [],
        teams: [],

        // data
        axis1Opts: {
          dataKey: 'item',
          line: null,
          tickLine: null,
          grid: {
            lineStyle: {
              lineDash: null
            },
            hideFirstLine: false
          }
        },
        axis2Opts: {
          dataKey: 'score',
          line: null,
          tickLine: null,
          grid: {
            type: 'polygon',
            lineStyle: {
              lineDash: null
            }
          }
        },
        scale: [{
          dataKey: 'score',
          min: 0,
          max: 80
        }],
        axisData: [
          {item: '引用', a: 70, b: 30, c: 40},
          {item: '口碑', a: 60, b: 70, c: 40},
          {item: '产量', a: 50, b: 60, c: 40},
          {item: '贡献', a: 40, b: 50, c: 40},
          {item: '热度', a: 60, b: 70, c: 40},
          {item: '引用', a: 70, b: 50, c: 40}
        ],
        radarData: []
      }
    },
    computed: {
      userInfo() {
        return this.$store.getters.userInfo
      }
    },
    created() {
      this.user = this.userInfo
      this.avatar = this.userInfo.avatar

      getRoleList().then(res => {
        console.log('workplace -> call getRoleList()', res)
      })

      getServiceList().then(res => {
        console.log('workplace -> call getServiceList()', res)
      })
    },
    mounted() {
      this.getProjects()
      this.getActivity()
      this.getTeams()
      this.initRadar()
    },
    methods: {
      ...mapGetters(['nickname', 'welcome']),
      getProjects() {
        this.$http.get('/list/search/projects')
          .then(res => {
            this.projects = res.result && res.result.data
            this.loading = false
          })
      },
      getActivity() {
        this.$http.get('/workplace/activity')
          .then(res => {
            this.activities = res.result
          })
      },
      getTeams() {
        this.$http.get('/workplace/teams')
          .then(res => {
            this.teams = res.result
          })
      },
      initRadar() {
        this.radarLoading = true

        this.$http.get('/workplace/radar')
          .then(res => {
            const dv = new DataSet.View().source(res.result)
            dv.transform({
              type: 'fold',
              fields: ['个人', '团队', '部门'],
              key: 'user',
              value: 'score'
            })

            this.radarData = dv.rows
            this.radarLoading = false
          })
      }
    }
  }
</script>

<style  scoped>

  /* 首页横幅 */
  .ant-carousel>>>.slick-slide {
    text-align: center;
    height: 320px;
    line-height: 160px;
    background: #364d79;
    overflow: hidden;
  }

  .ant-carousel>>> .custom-slick-arrow {
    width: 25px;
    height: 25px;
    font-size: 25px;
    color: #fff;
    background-color: rgba(31, 45, 61, 0.11);
    opacity: 0.3;
  }

  .ant-carousel >>> .custom-slick-arrow:before {
    display: none;
  }

  .ant-carousel >>> .custom-slick-arrow:hover {
    opacity: 0.5;
  }

  .ant-carousel >>> .slick-slide h3 {
    color: #fff;
  }


  .project-list {

    .card-title {
      font-size: 0;

      a {
        color: rgba(0, 0, 0, 0.85);
        margin-left: 12px;
        line-height: 24px;
        height: 24px;
        display: inline-block;
        vertical-align: top;
        font-size: 14px;

        &:hover {
          color: #1890ff;
        }
      }
    }

    .card-description {
      color: rgba(0, 0, 0, 0.45);
      height: 44px;
      line-height: 22px;
      overflow: hidden;
    }

    .project-item {
      display: flex;
      margin-top: 8px;
      overflow: hidden;
      font-size: 12px;
      height: 20px;
      line-height: 20px;

      a {
        color: rgba(0, 0, 0, 0.45);
        display: inline-block;
        flex: 1 1 0;

        &:hover {
          color: #1890ff;
        }
      }

      .datetime {
        color: rgba(0, 0, 0, 0.25);
        flex: 0 0 auto;
        float: right;
      }
    }

    .ant-card-meta-description {
      color: rgba(0, 0, 0, 0.45);
      height: 44px;
      line-height: 22px;
      overflow: hidden;
    }
  }

  .item-group {
    padding: 20px 0 8px 24px;
    font-size: 0;

    a {
      color: rgba(0, 0, 0, 0.65);
      display: inline-block;
      font-size: 14px;
      margin-bottom: 13px;
      width: 25%;
    }
  }

  .members {
    a {
      display: block;
      margin: 12px 0;
      line-height: 24px;
      height: 24px;

      .member {
        font-size: 14px;
        color: rgba(0, 0, 0, .65);
        line-height: 24px;
        max-width: 100px;
        vertical-align: top;
        margin-left: 12px;
        transition: all 0.3s;
        display: inline-block;
      }

      &:hover {
        span {
          color: #1890ff;
        }
      }
    }
  }

  .mobile {

    .project-list {

      .project-card-grid {
        width: 100%;
      }
    }

    .more-info {
      border: 0;
      padding-top: 16px;
      margin: 16px 0 16px;
    }

    .headerContent .title .welcome-text {
      display: none;
    }
  }

</style>
